
var app = angular.module('theapp', []);

app.controller('MainCtrl', function($scope) {
  $scope.welcome = 'Hello world! This is HTML5 Boilerplate.';
});